import React, {Component, PropTypes} from 'react';

const propTypes = {};

const defaultProps = {};

export default class CardActions extends Component {
    render() {
        return (
            <div>Footer</div>
        );
    }
}

CardActions.propTypes = propTypes;
CardActions.defaultProps = defaultProps;
