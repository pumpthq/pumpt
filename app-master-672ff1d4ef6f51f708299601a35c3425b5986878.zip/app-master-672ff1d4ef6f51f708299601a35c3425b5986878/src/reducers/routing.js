import { routerReducer } from 'react-router-redux';

export default routerReducer;
