import H1 from './h1';
import H2 from './h2';
import H3 from './h3';

export {
    H1,
    H2,
    H3,
};
