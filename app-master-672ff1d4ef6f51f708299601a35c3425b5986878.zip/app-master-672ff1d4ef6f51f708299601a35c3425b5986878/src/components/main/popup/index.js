import PopUpBig from './PopupBig'

export default PopUpBig
