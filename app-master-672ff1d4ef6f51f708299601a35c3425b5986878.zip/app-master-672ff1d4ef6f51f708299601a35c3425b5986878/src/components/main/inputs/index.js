import {
    SimpleInput
} from './simple'

export {
    SimpleInput
}
