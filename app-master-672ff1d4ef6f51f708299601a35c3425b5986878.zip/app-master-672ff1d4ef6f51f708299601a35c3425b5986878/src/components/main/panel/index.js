import Panel from './panel'

export default Panel
