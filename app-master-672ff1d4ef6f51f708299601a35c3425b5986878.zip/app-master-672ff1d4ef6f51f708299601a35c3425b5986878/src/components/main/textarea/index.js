import ApplicationTextarea from './applicationTextarea'

export default ApplicationTextarea
