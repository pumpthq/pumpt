React component example:

    <Layout>Content will be here</Layout>
