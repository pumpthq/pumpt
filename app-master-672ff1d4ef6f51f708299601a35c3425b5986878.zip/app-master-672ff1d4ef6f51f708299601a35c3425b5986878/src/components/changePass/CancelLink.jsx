import React from 'react';

export default props => (
    <span className="link" onClick={props.handleClose}>
        Cancel
    </span>
);
