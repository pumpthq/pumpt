import OnboardingInput from './onboardingInput';

export {
    OnboardingInput
}
