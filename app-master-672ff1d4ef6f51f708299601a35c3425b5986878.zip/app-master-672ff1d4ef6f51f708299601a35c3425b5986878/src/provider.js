import { Provider } from 'react-redux'

export default Provider
